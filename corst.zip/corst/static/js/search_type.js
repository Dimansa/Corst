$('#search_02').click(function() {
    $("#search2").removeClass('d-none');
    $("#search1").addClass('d-none');
});

$('#search_01').click(function() {
    $("#search1").removeClass('d-none');
    $("#search2").addClass('d-none');
});